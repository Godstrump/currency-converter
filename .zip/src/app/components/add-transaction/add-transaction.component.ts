import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { User } from 'src/app/models/user.model';
import { Currency, Wallet } from 'src/app/models/wallet.model';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { TransactionService } from 'src/app/services/transaction.service';
import { Utility } from 'src/app/utility.utils';
@Component({
  selector: 'app-add-transaction',
  templateUrl: './add-transaction.component.html',
  styleUrls: ['./add-transaction.component.css'],
})
export class AddTransactionComponent extends Utility implements OnInit {
  wallet: Wallet | any;
  currencies: Currency[] = [];
  users: User[] = [];
  transactionForm: FormGroup = new FormGroup({
    currencyFrom: new FormControl('USD', [Validators.required]),
    from: new FormControl('', [Validators.required]),
    to: new FormControl('', [Validators.required]),
    currencyTo: new FormControl('USD', [Validators.required]),
    createAt: new FormControl('', [Validators.required]),
    updatedAt: new FormControl('', [Validators.required]),
    amount: new FormControl(0, [Validators.required]),
    currency: new FormControl('', [Validators.required]),
  });
  currencyTypes = ['USD', 'EUR', 'NGN'];
  currencyRates: any = {};

  constructor(
    private authService: AuthenticationService,
    private transactionService: TransactionService
  ) {
    super();
  }

  ngOnInit(): void {
    this.fetchUsers();
    this.fetchRates();
  }

  fetchUsers() {
    this.authService.getUsers().subscribe((users) => {
      if (users.length) {
        this.users = users;
      }
    });
  }

  fetchRates() {
    this.transactionService.getCurrencyRates().subscribe((data: any) => {
      console.log(data);
      this.currencyRates = data.rates;
    });
  }

  receiveSelectedOutput(fromEvent: string, toEvent?: string) {
    console.log('from', fromEvent);
    console.log('to', toEvent);
    const rates = this.currencyRates;
    let from = 0;
    let to = 0;

    for (const currency in rates) {
      if (currency === fromEvent) from = rates[currency];
      if (currency === toEvent) to = rates[currency];
    }
    console.log('from', from);
    console.log('to', to);
  }

  selectUser(uid: string) {
    this.transactionService.selectUserWallet(uid).subscribe((wallet) => {
      this.wallet = wallet;
    });
  }

  get amount() {
    return this.transactionForm.value.amount;
  }

  convertMoney() {}

  submit(): void {
    if (this.transactionForm.invalid) return;
    console.log('transaction', this.transactionForm.value);
  }
}
