// import { Wallet } from './wallet.model';

export interface User {
  uid: string;
  displayName: string;
  email: string;
  // wallet: Wallet;
  createdAt: Date;
}
