import { Utility } from './utility.utils';

describe('Utility.Utils', () => {
  it('should create an instance', () => {
    expect(new Utility()).toBeTruthy();
  });
});
