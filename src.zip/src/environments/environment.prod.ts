export const environment = {
  useEmulators: false,
  production: true,
  firebase: {
    apiKey: 'AIzaSyBLQaqH6bRQChFTTCu_OgY8weCXAa0UKpI',
    authDomain: 'wiselike-105bf.firebaseapp.com',
    projectId: 'wiselike-105bf',
    storageBucket: 'wiselike-105bf.appspot.com',
    messagingSenderId: '858418872174',
    appId: '1:858418872174:web:1ef2f414a4796760198b7f',
    measurementId: 'G-P8R6KZZ9BQ',
  },
};
